<?php

    phpinfo();

